import React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { PaperProvider, Appbar, Text } from 'react-native-paper';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const Tab = createBottomTabNavigator();

function Header() {
  return (
    <Appbar.Header style={{ backgroundColor: '#000' }}>
      <Appbar.Content title="Gestão de Usuários" titleStyle={{ color: '#fff', fontWeight: 'bold' }} />
    </Appbar.Header>
  );
}

function GradientButton({ label, onPress }: { label: string; onPress: () => void }) {
  return (
    <View style={styles.buttonContainer}>
      <TouchableOpacity onPress={onPress} activeOpacity={0.85}>
        <LinearGradient
          colors={['#6A0DAD', '#FF69B4', '#FFDAB9']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.gradient}
        >
          <Text style={styles.buttonText}>{label}</Text>
        </LinearGradient>
      </TouchableOpacity>
    </View>
  );
}

function ScreenContent({ title, onPress }: { title: string; onPress: () => void }) {
  return (
    <View style={styles.screen}>
      <Text style={styles.text}>{title}</Text>
      <GradientButton label={title} onPress={onPress} />
    </View>
  );
}

function InserirScreen() {
  const handleInserir = () => {
    // Função de inserir
  };
  return <ScreenContent title="Inserir Usuário" onPress={handleInserir} />;
}

function BuscarScreen() {
  const handleBuscar = () => {
    // Função de buscar
  };
  return <ScreenContent title="Buscar Usuário" onPress={handleBuscar} />;
}

function AtualizarScreen() {
  const handleAtualizar = () => {
    // Função de atualizar
  };
  return <ScreenContent title="Atualizar Usuário" onPress={handleAtualizar} />;
}

function ExcluirScreen() {
  const handleExcluir = () => {
    // Função de excluir
  };
  return <ScreenContent title="Excluir Usuário" onPress={handleExcluir} />;
}

export default function App() {
  return (
    <PaperProvider>
      <NavigationContainer>
        <Header />
        <Tab.Navigator
          screenOptions={{
            tabBarStyle: {
              backgroundColor: '#000',
              borderTopColor: '#222',
            },
            tabBarActiveTintColor: '#FF69B4',
            tabBarInactiveTintColor: '#666',
            headerShown: false,
          }}
        >
          <Tab.Screen
            name="Inserir"
            component={InserirScreen}
            options={{
              tabBarIcon: ({ color, size }) => (
                <MaterialCommunityIcons name="account-plus" color={color} size={size} />
              ),
            }}
          />
          <Tab.Screen
            name="Buscar"
            component={BuscarScreen}
            options={{
              tabBarIcon: ({ color, size }) => (
                <MaterialCommunityIcons name="account-search" color={color} size={size} />
              ),
            }}
          />
          <Tab.Screen
            name="Atualizar"
            component={AtualizarScreen}
            options={{
              tabBarIcon: ({ color, size }) => (
                <MaterialCommunityIcons name="account-edit" color={color} size={size} />
              ),
            }}
          />
          <Tab.Screen
            name="Excluir"
            component={ExcluirScreen}
            options={{
              tabBarIcon: ({ color, size }) => (
                <MaterialCommunityIcons name="account-remove" color={color} size={size} />
              ),
            }}
          />
        </Tab.Navigator>
      </NavigationContainer>
    </PaperProvider>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  text: {
    color: '#fff',
    fontSize: 24,
    fontWeight: '600',
    marginBottom: 20,
    textAlign: 'center',
  },
  buttonContainer: {
    width: '100%',
    alignItems: 'center',
  },
  gradient: {
    minWidth: 200,
    maxWidth: '90%',
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#FF69B4',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 5,
  },
  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
    textAlign: 'center',
    flexWrap: 'nowrap',
  },
});
